# 프론트엔드 UI 개발 프롬프트

## 스킬 참조 (필수)

각 프롬프트 실행 전 아래 스킬을 로드하세요:

| 스킬 명령어 | 설명 | 사용 시점 |
|------------|------|----------|
| `/equipment-management` | 역할 체계, 승인 프로세스, 장비 관리 도메인 지식 | 모든 UI 개발 시 |
| `/nextjs-16` | Next.js 16 App Router, PageProps, useActionState 패턴 | 페이지/레이아웃 개발 시 |
| `/frontend-design` | 고품질 프론트엔드 인터페이스 디자인, 컴포넌트 스타일링 | UI 컴포넌트 디자인 시 |
| `/playwright-skill` | Playwright 브라우저 자동화 및 테스트 | E2E 테스트 작성 시 |

### 스킬 로드 예시

```
/equipment-management
/nextjs-16
/frontend-design
```

---

## 문서 참조

- **API 표준**: `/docs/development/API_STANDARDS.md`
- **구현 프롬프트**: `/docs/development/PROMPTS_FOR_IMPLEMENTATION_v2.md`
- **프로젝트 상태**: `/docs/development/PROJECT_STATUS.md`

---

## Playwright 테스트 가이드

### 테스트 환경 설정

```bash
# Playwright 설치 (최초 1회)
pnpm exec playwright install

# 테스트 실행
cd apps/frontend
pnpm exec playwright test

# 특정 파일 테스트
pnpm exec playwright test tests/e2e/dashboard.spec.ts

# UI 모드로 테스트
pnpm exec playwright test --ui

# 디버그 모드
pnpm exec playwright test --debug
```

### 테스트 파일 위치

```
apps/frontend/
├── tests/
│   └── e2e/
│       ├── fixtures/
│       │   └── auth.fixture.ts      # 역할별 로그인 픽스처
│       ├── dashboard.spec.ts        # 대시보드 테스트
│       ├── equipment.spec.ts        # 장비 목록 테스트
│       ├── approvals.spec.ts        # 승인 관리 테스트
│       ├── notifications.spec.ts    # 알림 테스트
│       ├── reports.spec.ts          # 보고서 테스트
│       └── accessibility.spec.ts    # 접근성 테스트
├── playwright.config.ts
```

### 역할별 로그인 픽스처

```typescript
// tests/e2e/fixtures/auth.fixture.ts
import { test as base, Page } from '@playwright/test';

interface AuthFixtures {
  testOperatorPage: Page;
  techManagerPage: Page;
  siteAdminPage: Page;
  systemAdminPage: Page;
}

export const test = base.extend<AuthFixtures>({
  testOperatorPage: async ({ browser }, use) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    await loginAs(page, 'test_operator');
    await use(page);
    await context.close();
  },

  techManagerPage: async ({ browser }, use) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    await loginAs(page, 'technical_manager');
    await use(page);
    await context.close();
  },

  siteAdminPage: async ({ browser }, use) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    await loginAs(page, 'site_admin');
    await use(page);
    await context.close();
  },

  systemAdminPage: async ({ browser }, use) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    await loginAs(page, 'system_admin');
    await use(page);
    await context.close();
  },
});

async function loginAs(page: Page, role: string) {
  // 테스트 환경에서는 mock 인증 또는 테스트 계정 사용
  await page.goto('/api/auth/test-login?role=' + role);
  await page.waitForURL('/dashboard');
}

export { expect } from '@playwright/test';
```

---

## 공통 요구사항

모든 프론트엔드 UI 개발 시 아래 사항을 준수하세요:

### 디자인 원칙

- **일관성**: shadcn/ui 컴포넌트 라이브러리 사용
- **반응형**: 모바일(320px) ~ 데스크톱(1920px) 대응
- **접근성**: WCAG 2.1 AA 수준 준수
- **성능**: Core Web Vitals 기준 충족

### 기술 스택

```typescript
// 컴포넌트 구조
'use client'; // 클라이언트 컴포넌트 명시

import { useActionState } from 'react'; // Next.js 16 패턴
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
```

### 역할별 UI 분기

```typescript
// 역할에 따른 조건부 렌더링
const { user } = useAuth();

const canApprove = ['technical_manager', 'site_admin', 'system_admin'].includes(user.role);
const canManageAllSites = ['site_admin', 'system_admin'].includes(user.role);
```
=== 1. 디자인 요구사항 (UL Solutions Corporate Professional) ===

1.1 브랜딩 섹션 (좌측, 데스크톱 전용)
- 배경: UL Midnight Blue (#122C49) 단색
- 미묘한 그리드 패턴 오버레이 (40px 간격)
- 로고 영역: 상단 좌측
  - UL Red (#CA0123) 배경의 Wrench 아이콘
  - "장비 관리 시스템" + "Equipment Management System" 텍스트
- 중앙: 메인 헤드라인
  - "효율적인 장비 관리를 통합 솔루션으로"
  - UL Info (#BCE4F7) 하이라이트 텍스트
- 하단: 3개의 기능 하이라이트 카드 (아이콘 + 짧은 설명)
  - 체계적인 장비 관리
  - 실시간 교정 추적
  - 역할 기반 승인
- 최하단: UL Solutions 브랜딩 ("UL Solutions | Quality & Safety")
- 부드러운 fade-in 애니메이션 (페이지 로드 시)

1.2 로그인 폼 섹션 (우측)
- 배경: 흰색 (bg-white) / 다크모드 시 배경색 자동 적용
- 카드: 흰색, 부드러운 그림자 (shadow-lg), 둥근 모서리 (rounded-2xl)
- 상단: 환영 메시지 ("Welcome back", "계정에 로그인하여 시작하세요")
- Azure AD 버튼 우선 배치 (Microsoft 계정으로 로그인)
- "또는" 구분선 (Separator with text)
- 이메일/비밀번호 폼
- 폼 필드: 아이콘 prefix (Mail, Lock 아이콘)
- 로그인 버튼: UL Midnight Blue (#122C49), hover 시 darker
- 하단: 테스트 계정 정보 (개발 환경)

1.3 반응형 디자인
- 모바일 (< 1024px): 브랜딩 섹션 숨김, 로그인 폼만 전체 화면
- 모바일 상단에 Midnight Blue 헤더 + UL Red 로고 아이콘
- 데스크톱 (≥ 1024px): 브랜딩 50%, 로그인 50% 스플릿 레이아웃

1.4 인터랙션 & 애니메이션
- 입력 필드 포커스: Primary 색상 테두리 + ring 효과
- 버튼 hover: 배경색 진하게 (ul-midnight-dark) + 약간의 scale (1.01)
- 로딩 상태: 스피너 + 버튼 텍스트 변경 + 버튼 비활성화
- 에러 상태: shake 애니메이션 (폼 전체), UL Red 테두리
- 성공 시: UL Green 배경 + checkmark 애니메이션 후 리다이렉트

1.5 색상 팔레트 (UL Solutions Brand)
- Primary: #122C49 (Midnight Blue) - 메인 버튼, 헤더, 사이드바
- Primary Hover: #0a1c30 (Darker Midnight)
- Secondary: #577E9E (Fog) - 보조 텍스트
- Brand Accent: #CA0123 (Bright Red) - 로고, CTA, 중요 배지
- Error: #CA0123 (Bright Red) - 오류, 부적합
- Success: #00A451 (Bright Green) - 정상, 승인 완료
- Warning: #FF9D55 (Orange) - 교정 예정, 주의
- Info: #BCE4F7 (Light Blue) - 정보 배경, 하이라이트
- Background: #EBEBEB (UL Gray) - 페이지 배경
- Surface: #FFFFFF - 카드, 모달 배경
- Border: #D8D9DA (UL Gray 1) - 테두리
- Text Primary: #122C49 (Midnight Blue)
- Text Muted: #577E9E (Fog)

1.6 다크모드 지원
- next-themes 라이브러리 활용
- 헤더에 다크모드 토글 버튼 (Sun/Moon/Monitor 아이콘)
- 시스템 설정 자동 감지 + 수동 토글 지원
- CSS Variables 기반 색상 시스템으로 자동 전환

---

## UI-5: 보고서/대장 출력

### 목적

PDF/Excel 출력 기능을 제공합니다.

### 프롬프트

```
스킬 로드:
/equipment-management
/nextjs-16
/frontend-design

AGENTS.md와 /docs/development/API_STANDARDS.md를 참조하여 보고서/대장 출력 기능을 구현해줘.

요구사항:
1. 교정계획서 PDF 출력
   - 페이지 경로: /reports/calibration-plan/[id]/print
   - 인쇄 최적화 스타일 (A4)
   - 헤더: 로고, 문서번호, 버전, 날짜
   - 내용: 교정 대상 장비 목록, 일정, 담당자
   - 서명란: 작성자, 검토자, 승인자

2. 보정계수 대장 Excel 내보내기
   - 장비별 보정계수 이력
   - 날짜 범위 필터
   - 열: 장비명, 측정항목, 보정계수, 등록일, 등록자
   - xlsx 파일 다운로드

3. 장비 이력카드 PDF 출력
   - 장비 기본 정보
   - 교정 이력
   - 수리 이력
   - 대여/반출 이력
   - QR 코드 (장비 상세 페이지 링크)

4. 인쇄 미리보기
   - 모달 또는 새 탭
   - 실제 인쇄 전 확인
   - 인쇄 버튼

파일:
- apps/frontend/app/reports/calibration-plan/[id]/print/page.tsx
- apps/frontend/app/reports/equipment-history/[id]/print/page.tsx
- apps/frontend/components/reports/CalibrationPlanPrint.tsx
- apps/frontend/components/reports/EquipmentHistoryPrint.tsx
- apps/frontend/components/reports/PrintLayout.tsx (공통 인쇄 레이아웃)
- apps/frontend/components/reports/ExportButton.tsx
- apps/frontend/components/reports/PrintPreviewModal.tsx
- apps/frontend/lib/utils/export-utils.ts (Excel 생성)
- apps/frontend/lib/utils/pdf-utils.ts (PDF 생성)

라이브러리:
- xlsx: Excel 파일 생성
- @react-pdf/renderer 또는 브라우저 print() API

디자인 요구사항 (/frontend-design 스킬 활용):
- 인쇄 스타일: 흑백 최적화, 페이지 나눔 제어
- 표: 테두리, 헤더 배경색
- 버튼: 다운로드 아이콘 + 파일 형식 표시
- 로딩 상태: 스피너 + "생성 중..." 텍스트

제약사항:
- PDF는 A4 크기 최적화
- Excel은 5000행 이하 권장
- 대용량 데이터는 서버 사이드 생성 고려

검증:
- PDF 다운로드 및 인쇄 확인
- Excel 파일 생성 및 내용 확인
- 인쇄 미리보기 동작 확인

Playwright 테스트:
- PDF 다운로드 트리거 확인
- Excel 파일 생성 확인 (다운로드 후 파일 검증)
- 인쇄 미리보기 모달 동작 확인

완료 후 체크리스트의 [ ]를 [x]로 변경해주세요.
```

### 이행 체크리스트 UI-5

- [ ] calibration-plan/[id]/print/page.tsx 생성됨
- [ ] equipment-history/[id]/print/page.tsx 생성됨
- [ ] CalibrationPlanPrint.tsx 컴포넌트 생성됨
- [ ] EquipmentHistoryPrint.tsx 컴포넌트 생성됨
- [ ] PrintLayout.tsx 공통 레이아웃 생성됨
- [ ] ExportButton.tsx 컴포넌트 생성됨
- [ ] PrintPreviewModal.tsx 컴포넌트 생성됨
- [ ] export-utils.ts 유틸리티 생성됨
- [ ] pdf-utils.ts 유틸리티 생성됨
- [ ] PDF 인쇄 스타일 구현됨 (A4 최적화)
- [ ] Excel 다운로드 구현됨
- [ ] QR 코드 생성 구현됨
- [ ] Playwright 테스트 작성됨 (reports.spec.ts)
- [ ] 모든 테스트 통과됨

### Playwright 테스트 예시

```typescript
// tests/e2e/reports.spec.ts
import { test, expect } from './fixtures/auth.fixture';
import * as fs from 'fs';
import * as path from 'path';

test.describe('Reports', () => {
  test('교정계획서 인쇄 미리보기', async ({ siteAdminPage }) => {
    await siteAdminPage.goto('/reports/calibration-plan/1');

    // 인쇄 버튼 클릭
    await siteAdminPage.getByRole('button', { name: '인쇄' }).click();

    // 미리보기 모달 표시 확인
    await expect(siteAdminPage.getByTestId('print-preview-modal'))
      .toBeVisible();
  });

  test('보정계수 대장 Excel 다운로드', async ({ techManagerPage }) => {
    // 다운로드 이벤트 대기 설정
    const downloadPromise = techManagerPage.waitForEvent('download');

    await techManagerPage.goto('/calibration-factors');
    await techManagerPage.getByRole('button', { name: 'Excel 내보내기' }).click();

    // 다운로드 완료 확인
    const download = await downloadPromise;
    expect(download.suggestedFilename()).toMatch(/\.xlsx$/);
  });

  test('장비 이력카드 PDF', async ({ testOperatorPage }) => {
    await testOperatorPage.goto('/equipment/123');

    // PDF 다운로드 버튼 클릭
    const downloadPromise = testOperatorPage.waitForEvent('download');
    await testOperatorPage.getByRole('button', { name: '이력카드 PDF' }).click();

    const download = await downloadPromise;
    expect(download.suggestedFilename()).toMatch(/\.pdf$/);
  });
});
```

---

## 프롬프트 실행 순서

권장 실행 순서:

### Phase 1: 기반 작업
1. **UI-6: 반응형 레이아웃 및 접근성** (기반 작업)
2. **UI-7: 로그인/인증 페이지** (인증 기반)

### Phase 2: 핵심 페이지
3. **UI-1: 역할별 대시보드** (메인 페이지)
4. **UI-8: 장비 등록/수정 폼** (장비 CRUD)
5. **UI-9: 장비 상세 페이지** (장비 상세)
6. **UI-2: 장비 목록/검색 UI 개선** (장비 목록)

### Phase 3: 교정 관리
7. **UI-10: 교정 관리 페이지** (교정 CRUD)
8. **UI-11: 교정계획서 관리** (교정계획서)
9. **UI-14: 보정계수 관리 페이지** (보정계수)

### Phase 4: 대여/반출 관리
10. **UI-12: 대여 관리 페이지** (대여)
11. **UI-13: 반출/반입 관리 페이지** (반출/반입)

### Phase 5: 부가 기능
12. **UI-15: 부적합 장비 관리** (부적합)
13. **UI-16: 수리이력 관리** (수리)
14. **UI-17: 소프트웨어 관리대장** (소프트웨어)

### Phase 6: 관리 기능
15. **UI-3: 승인 관리 통합 페이지** (승인 통합)
16. **UI-4: 알림 센터** (알림)
17. **UI-18: 팀 관리 페이지** (팀)
18. **UI-19: 설정 및 관리자 페이지** (설정)

### Phase 7: 출력 기능
19. **UI-5: 보고서/대장 출력** (출력)

각 프롬프트 완료 후 Playwright 테스트를 실행하여 기능을 검증하세요.

---

## 스킬 활용 요약

| 프롬프트 | equipment-management | nextjs-16 | frontend-design | playwright-skill |
|---------|---------------------|-----------|-----------------|------------------|
| UI-1 대시보드 | ✅ 역할 체계 | ✅ App Router | ✅ 카드 디자인 | ✅ 역할별 테스트 |
| UI-2 장비 목록 | ✅ 장비 상태 | ✅ URL 상태 | ✅ 테이블/카드 | ✅ 필터 테스트 |
| UI-3 승인 관리 | ✅ 승인 프로세스 | ✅ Server Actions | ✅ 탭/모달 | ✅ 승인 플로우 |
| UI-4 알림 | ✅ 알림 유형 | ✅ 클라이언트 | ✅ 드롭다운 | ✅ 알림 테스트 |
| UI-5 보고서 | ✅ 교정계획서 | ✅ 동적 라우트 | ✅ 인쇄 스타일 | ✅ 다운로드 |
| UI-6 접근성 | - | ✅ 레이아웃 | ✅ 반응형 | ✅ a11y 테스트 |
| UI-7 로그인 | ✅ 역할 체계 | ✅ NextAuth | ✅ 로그인 폼 | ✅ 인증 테스트 |
| UI-8 장비 폼 | ✅ 장비 필드 | ✅ 폼 처리 | ✅ 폼 디자인 | ✅ 폼 테스트 |
| UI-9 장비 상세 | ✅ 장비 상태 | ✅ 탭 라우팅 | ✅ 탭/배너 | ✅ 상세 테스트 |
| UI-10 교정 | ✅ 교정 프로세스 | ✅ Server Actions | ✅ 폼/목록 | ✅ 교정 테스트 |
| UI-11 교정계획서 | ✅ 교정계획서 | ✅ 동적 라우트 | ✅ 일정 UI | ✅ 계획서 테스트 |
| UI-12 대여 | ✅ 대여 프로세스 | ✅ Server Actions | ✅ 캘린더 | ✅ 대여 테스트 |
| UI-13 반출 | ✅ 반출 프로세스 | ✅ Server Actions | ✅ 검사 폼 | ✅ 반출 테스트 |
| UI-14 보정계수 | ✅ 보정계수 | ✅ 동적 라우트 | ✅ JSON 에디터 | ✅ 보정계수 테스트 |
| UI-15 부적합 | ✅ 부적합 관리 | ✅ Server Actions | ✅ 타임라인 | ✅ 부적합 테스트 |
| UI-16 수리이력 | ✅ 수리 관리 | ✅ 동적 라우트 | ✅ 타임라인 | ✅ 수리 테스트 |
| UI-17 소프트웨어 | ✅ 소프트웨어 | ✅ 동적 라우트 | ✅ 라이선스 UI | ✅ SW 테스트 |
| UI-18 팀 관리 | ✅ 팀 구조 | ✅ 동적 라우트 | ✅ 팀 카드 | ✅ 팀 테스트 |
| UI-19 설정 | ✅ 시스템 설정 | ✅ Server Actions | ✅ 토글 UI | ✅ 설정 테스트 |
